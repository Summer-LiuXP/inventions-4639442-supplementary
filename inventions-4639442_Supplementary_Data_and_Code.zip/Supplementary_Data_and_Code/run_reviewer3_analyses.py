"""Reviewer-3 robustness, component, boundary, and cost analyses.

This script uses the public ETT traces and the article's synthetic stress
generators. It does not introduce external or proprietary data. The sensitivity
runs use five representative seeds to keep the reproducibility package
practical while the primary claims remain based on the 20-seed benchmark.
"""
from __future__ import annotations

import gc
import json
import math
import os
import statistics
import time
import tracemalloc
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
try:
    import psutil
except ImportError:
    psutil = None
from scipy.stats import t as student_t
from scipy.stats import ttest_rel, wilcoxon

from run_reviewer2_controls import (
    BASE_COLS,
    COOLDOWN_HOURS,
    D_MODEL,
    DRIFT_REPLAY_MIN,
    GATE_GRID,
    HORIZON,
    L2,
    LOCAL_LR,
    LOOKBACK,
    PERIODIC_INTERVAL,
    PERIODIC_REPLAY_MIN,
    REPLAY_CAP,
    add_time_features,
    balanced_indices,
    choose_gate,
    prepare_split,
    rpa_features,
    sgd_update,
)

warnings.filterwarnings("ignore")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

ROOT = Path(__file__).resolve().parent
RESDIR = ROOT / "results"
RESDIR.mkdir(parents=True, exist_ok=True)
SENSITIVITY_SEEDS = [1, 42, 89, 202, 303]
DATASETS = ["ETTSwitch", "ControlledDrift"]
BOUNDARY_WINDOWS = [24, 48, 168]
PH_MULTIPLIERS = [3.0, 5.0, 7.0]
COOLDOWNS = [84, 168, 336]
SWITCH_INTERVALS = [168, 336, 504]


def make_controlled_drift_variant(
    n: int = 12000,
    seed: int = 7,
    interval_hours: int = 504,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    date = pd.date_range("2016-01-01", periods=n, freq="h")
    daily = np.sin(2 * np.pi * t / 24)
    weekly = np.cos(2 * np.pi * t / (24 * 7))
    slow = np.sin(2 * np.pi * t / (24 * 60))
    signal = daily + 0.6 * weekly + 0.25 * rng.normal(size=n)

    split_a = int(n * 0.80)
    regime = np.ones(n)
    for st in range(split_a, n, interval_hours):
        block_index = (st - split_a) // interval_hours
        regime[st : st + interval_hours] = 1 if block_index % 2 == 0 else -1

    hu = signal + 0.15 * rng.normal(size=n)
    mu = 0.7 * signal + 0.4 * slow + 0.15 * rng.normal(size=n)
    lu = -0.5 * signal + 0.3 * weekly + 0.15 * rng.normal(size=n)
    base = 12 + 1.3 * slow + 0.2 * weekly

    ot = (
        base
        + 0.35 * np.roll(base, 24)
        + 1.9 * regime * np.roll(signal, 24)
        + 0.22 * rng.normal(size=n)
    )
    ot[:24] = base[:24] + 1.9 * signal[:24] + 0.22 * rng.normal(size=24)

    return pd.DataFrame(
        {
            "date": date,
            "HUFL": hu,
            "HULL": hu * 0.45 + 0.1 * rng.normal(size=n),
            "MUFL": mu,
            "MULL": mu * 0.45 + 0.1 * rng.normal(size=n),
            "LUFL": lu,
            "LULL": lu * 0.45 + 0.1 * rng.normal(size=n),
            "OT": ot.astype("float32"),
        }
    )


def load_ett_switch(block_hours: int) -> tuple[pd.DataFrame, list[int], int]:
    h1 = pd.read_csv(ROOT / "ETTh1.csv")
    h2 = pd.read_csv(ROOT / "ETTh2.csv")
    total = min(16000, len(h1), len(h2))
    prefix = int(total * 0.80)
    parts = [h1.iloc[:prefix].copy()]
    pos1 = prefix
    pos2 = prefix

    while sum(len(part) for part in parts) < total:
        current_length = sum(len(part) for part in parts)
        block_index = (current_length - prefix) // block_hours
        if block_index % 2 == 0:
            segment = h2.iloc[pos2 : pos2 + block_hours].copy()
            pos2 += block_hours
        else:
            segment = h1.iloc[pos1 : pos1 + block_hours].copy()
            pos1 += block_hours
        if len(segment) == 0:
            break
        parts.append(segment)

    df = pd.concat(parts, ignore_index=True).iloc[:total].copy()
    df["date"] = pd.date_range("2016-01-01", periods=len(df), freq="h")
    switch_rows = list(range(prefix, total, block_hours))
    return df, switch_rows, prefix


def dataframe_to_windows(df: pd.DataFrame, name: str) -> dict:
    df = add_time_features(df)
    time_cols = ["hour_sin", "hour_cos", "dow_sin", "dow_cos", "doy_sin", "doy_cos"]
    cols = BASE_COLS + time_cols
    raw_x = df[cols].values.astype("float32")
    raw_y = df["OT"].values.astype("float32")
    xs, ys, y_last, dates = [], [], [], []

    for i in range(len(df) - LOOKBACK - HORIZON + 1):
        xs.append(raw_x[i : i + LOOKBACK])
        ys.append(raw_y[i + LOOKBACK + HORIZON - 1])
        y_last.append(raw_y[i + LOOKBACK - 1])
        dates.append(df["date"].iloc[i + LOOKBACK + HORIZON - 1])

    return {
        "name": name,
        "raw_ot": raw_y,
        "X": np.stack(xs),
        "y": np.asarray(ys, dtype="float32"),
        "y_last": np.asarray(y_last, dtype="float32"),
        "dates": pd.to_datetime(pd.Series(dates)),
    }


def load_variant(
    dataset_name: str,
    switch_block_hours: int = 168,
    controlled_interval_hours: int = 504,
) -> tuple[dict, list[int]]:
    if dataset_name == "ETTSwitch":
        df, switch_rows, _ = load_ett_switch(switch_block_hours)
    elif dataset_name == "ControlledDrift":
        df = make_controlled_drift_variant(interval_hours=controlled_interval_hours)
        split_a = int(len(df) * 0.80)
        switch_rows = list(
            range(split_a + controlled_interval_hours, len(df), controlled_interval_hours)
        )
    else:
        raise ValueError(dataset_name)
    return dataframe_to_windows(df, dataset_name), switch_rows


def ci_mean(values: np.ndarray) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    n = values.size
    if n < 2:
        return float(values.mean()), float("nan")
    standard_error = values.std(ddof=1) / math.sqrt(n)
    half_width = float(student_t.ppf(0.975, n - 1) * standard_error)
    return float(values.mean() - half_width), float(values.mean() + half_width)


def paired_statistics(
    dataset: str,
    comparison: str,
    left: np.ndarray,
    right: np.ndarray,
    family: str,
) -> dict:
    left = np.asarray(left, dtype=float)
    right = np.asarray(right, dtype=float)
    difference = left - right
    t_result = ttest_rel(left, right)
    ci_low, ci_high = ci_mean(difference)
    sd = difference.std(ddof=1)
    effect_size = difference.mean() / sd if sd > 0 else float("nan")
    try:
        wilcoxon_result = wilcoxon(difference, alternative="two-sided")
        wilcoxon_stat = float(wilcoxon_result.statistic)
        wilcoxon_p = float(wilcoxon_result.pvalue)
    except ValueError:
        wilcoxon_stat = float("nan")
        wilcoxon_p = float("nan")
    return {
        "family": family,
        "dataset": dataset,
        "comparison": comparison,
        "n_pairs": int(len(difference)),
        "mean_difference": float(difference.mean()),
        "ci95_low": ci_low,
        "ci95_high": ci_high,
        "paired_t_statistic": float(t_result.statistic),
        "paired_t_p_value": float(t_result.pvalue),
        "cohens_dz": float(effect_size),
        "wilcoxon_statistic": wilcoxon_stat,
        "wilcoxon_p_value": wilcoxon_p,
    }


def make_statistical_tables() -> tuple[pd.DataFrame, pd.DataFrame]:
    primary = pd.read_csv(RESDIR / "metrics_by_dataset_seed.csv")
    primary_rows = []
    primary_pairs = [
        ("Static gated minus Static ungated", "Static RPA observer (gated)", "Static RPA observer (ungated)"),
        ("AE-RPA gated minus Static gated", "AE-RPA observer (gated)", "Static RPA observer (gated)"),
        ("AE-RPA gated minus AE-RPA lambda=1", "AE-RPA observer (gated)", "AE-RPA observer (lambda=1)"),
    ]

    for dataset in [name for name in DATASETS + ["ETTh1", "ETTh2", "ETTm1"] if name in primary.dataset.unique()]:
        dataset_rows = primary[primary.dataset == dataset]
        pivot = dataset_rows.pivot(index="seed", columns="model", values="RMSE")
        for label, left_model, right_model in primary_pairs:
            if left_model in pivot and right_model in pivot:
                pair = pivot[[left_model, right_model]].dropna()
                primary_rows.append(
                    paired_statistics(
                        dataset,
                        label,
                        pair[left_model].values,
                        pair[right_model].values,
                        "primary-causal-and-gate",
                    )
                )

    controls = pd.read_csv(RESDIR / "reviewer2_controls_by_dataset_seed.csv")
    control_rows = []
    for dataset, group in controls.groupby("dataset"):
        pivot = group.pivot(index="seed", columns="model", values="RMSE")
        combined = pivot["AE-RPA combined"]
        for comparator in ["Local-update-only", "Periodic-refresh-only", "Drift-refresh-only"]:
            control_rows.append(
                paired_statistics(
                    dataset,
                    f"AE-RPA combined minus {comparator}",
                    combined.values,
                    pivot[comparator].values,
                    "budget-matched-controls",
                )
            )

    primary_stats = pd.DataFrame(primary_rows)
    control_stats = pd.DataFrame(control_rows)
    primary_stats.to_csv(RESDIR / "reviewer3_primary_statistical_tests.csv", index=False)
    control_stats.to_csv(RESDIR / "reviewer3_control_statistical_tests.csv", index=False)
    return primary_stats, control_stats


def simulate_general(
    split: dict,
    mode: str,
    *,
    target_budget: int | None = None,
    ph_multiplier: float = 5.0,
    cooldown_hours: int = COOLDOWN_HOURS,
    periodic_interval: int = PERIODIC_INTERVAL,
    smoothing: float = 0.995,
    tolerance: float = 0.01,
) -> tuple[dict, dict, np.ndarray, list[int], list[int]]:
    allowed = {"local", "periodic", "drift", "combined"}
    if mode not in allowed:
        raise ValueError(mode)

    test_idx = split["test_idx"]
    feat = split["embedding"]
    resid = split["resid"]
    yls = split["yls"]
    ys = split["ys"]
    inv = split["inv"]
    val_idx = split["val_idx"]
    model = split["static_model"]
    gate = split["gate"]
    w = model.coef_.astype("float32").copy()
    b = float(model.intercept_)

    val_resid = model.predict(feat[val_idx])
    val_err = np.abs(val_resid - resid[val_idx])
    ph_mean = float(val_err.mean())
    ph_lambda = float(ph_mean + ph_multiplier * val_err.std() + 1e-6)
    smoothed_error = ph_mean
    cumulative = 0.0
    minimum_cumulative = 0.0

    queue: list[tuple[np.ndarray, float]] = []
    replay_x: list[np.ndarray] = []
    replay_y: list[float] = []
    predictions: list[float] = []
    drift_steps: list[int] = []
    periodic_steps: list[int] = []
    total_gradient_samples = 0
    cloud_gradient_samples = 0
    local_gradient_samples = 0
    budget_equalizer_samples = 0
    parameter_updates = 0
    last_drift_step = -10**9
    n_test = len(test_idx)

    def remaining() -> int | None:
        if target_budget is None:
            return None
        return max(0, target_budget - total_gradient_samples)

    def use_update(xb: np.ndarray, yb: np.ndarray, source: str) -> bool:
        nonlocal w, b, total_gradient_samples
        nonlocal cloud_gradient_samples, local_gradient_samples, parameter_updates
        rem = remaining()
        if rem is not None:
            if rem <= 0:
                return False
            if len(yb) > rem:
                keep = balanced_indices(len(yb), rem)
                xb = xb[keep]
                yb = yb[keep]
        w, b = sgd_update(w, b, xb, yb)
        used = len(yb)
        total_gradient_samples += used
        parameter_updates += 1
        if source == "cloud":
            cloud_gradient_samples += used
        else:
            local_gradient_samples += used
        return True

    for step, idx in enumerate(test_idx):
        predictions.append(yls[idx] + gate * float(feat[idx] @ w + b))
        queue.append((feat[idx], float(resid[idx])))

        if len(queue) > HORIZON:
            xb, yb = queue.pop(0)
            replay_x.append(xb)
            replay_y.append(yb)
            if len(replay_x) > REPLAY_CAP:
                replay_x.pop(0)
                replay_y.pop(0)

            err = abs(float(xb @ w + b) - yb)
            smoothed_error = smoothing * smoothed_error + (1 - smoothing) * err
            cumulative += err - smoothed_error - tolerance
            minimum_cumulative = min(minimum_cumulative, cumulative)

            drift_ready = (
                mode in {"drift", "combined"}
                and cumulative - minimum_cumulative > ph_lambda
                and len(replay_x) > DRIFT_REPLAY_MIN
                and (step - last_drift_step) >= cooldown_hours
            )
            periodic_ready = (
                mode in {"periodic", "combined"}
                and step > 0
                and step % periodic_interval == 0
                and len(replay_x) > PERIODIC_REPLAY_MIN
            )

            if drift_ready or periodic_ready:
                if drift_ready:
                    use_n = len(replay_x)
                    drift_steps.append(step)
                    last_drift_step = step
                    cumulative = 0.0
                    minimum_cumulative = 0.0
                else:
                    use_n = min(128, len(replay_x))
                    periodic_steps.append(step)
                use_x = np.asarray(replay_x[-use_n:], dtype="float32")
                use_y = np.asarray(replay_y[-use_n:], dtype="float32")
                for _ in range(2):
                    if not use_update(use_x, use_y, "cloud"):
                        break
            else:
                use_update(xb.reshape(1, -1), np.asarray([yb]), "local")

            if (
                target_budget is not None
                and step % 24 == 23
                and len(replay_x) >= 32
            ):
                expected = int(math.floor(target_budget * (step + 1) / n_test))
                to_add = expected - total_gradient_samples
                if to_add > 0:
                    use_n = min(to_add, len(replay_x))
                    positions = balanced_indices(len(replay_x), use_n)
                    extra_x = np.asarray(replay_x, dtype="float32")[positions]
                    extra_y = np.asarray(replay_y, dtype="float32")[positions]
                    before = total_gradient_samples
                    use_update(extra_x, extra_y, "local")
                    budget_equalizer_samples += total_gradient_samples - before

    if target_budget is not None and total_gradient_samples < target_budget and replay_x:
        to_add = min(target_budget - total_gradient_samples, len(replay_x))
        positions = balanced_indices(len(replay_x), to_add)
        extra_x = np.asarray(replay_x, dtype="float32")[positions]
        extra_y = np.asarray(replay_y, dtype="float32")[positions]
        before = total_gradient_samples
        use_update(extra_x, extra_y, "local")
        budget_equalizer_samples += total_gradient_samples - before

    prediction = inv(np.asarray(predictions, dtype="float32"))
    y_true = split["target"][test_idx]
    error = prediction - y_true
    metrics = {
        "RMSE": math.sqrt(float(np.mean(error**2))),
        "MAE": float(np.mean(np.abs(error))),
        "MASE": float(np.mean(np.abs(error)) / split["mase_den"]),
    }
    audit = {
        "gate": gate,
        "ph_threshold": ph_lambda,
        "ph_multiplier": ph_multiplier,
        "cooldown_hours": cooldown_hours,
        "periodic_interval": periodic_interval,
        "drift_events": len(drift_steps),
        "periodic_events": len(periodic_steps),
        "gradient_samples": total_gradient_samples,
        "local_gradient_samples": local_gradient_samples,
        "cloud_gradient_samples": cloud_gradient_samples,
        "budget_equalizer_samples": budget_equalizer_samples,
        "parameter_updates": parameter_updates,
    }
    return metrics, audit, prediction, drift_steps, periodic_steps


def static_predictions(split: dict) -> np.ndarray:
    model = split["static_model"]
    gate = split["gate"]
    test_idx = split["test_idx"]
    residual = model.predict(split["embedding"][test_idx])
    return split["inv"](split["yls"][test_idx] + gate * residual)


def boundary_metrics(
    dataset: str,
    seed: int,
    model_name: str,
    prediction: np.ndarray,
    y_true: np.ndarray,
    absolute_rows: np.ndarray,
    switch_rows: list[int],
) -> list[dict]:
    rows = []
    for window in BOUNDARY_WINDOWS:
        pre_mask = np.zeros(len(absolute_rows), dtype=bool)
        post_mask = np.zeros(len(absolute_rows), dtype=bool)
        for switch in switch_rows:
            pre_mask |= (absolute_rows >= switch - window) & (absolute_rows < switch)
            post_mask |= (absolute_rows >= switch) & (absolute_rows < switch + window)

        def rmse(mask: np.ndarray) -> float:
            if mask.sum() == 0:
                return float("nan")
            return math.sqrt(float(np.mean((prediction[mask] - y_true[mask]) ** 2)))

        pre_rmse = rmse(pre_mask)
        post_rmse = rmse(post_mask)
        rows.append(
            {
                "dataset": dataset,
                "seed": seed,
                "model": model_name,
                "window_hours": window,
                "pre_rmse": pre_rmse,
                "post_rmse": post_rmse,
                "post_minus_pre": post_rmse - pre_rmse,
                "pre_samples": int(pre_mask.sum()),
                "post_samples": int(post_mask.sum()),
            }
        )
    return rows


def detection_diagnostics(
    dataset: str,
    seed: int,
    drift_steps: list[int],
    absolute_rows: np.ndarray,
    switch_rows: list[int],
    detection_window: int = 168,
) -> tuple[list[dict], dict]:
    event_rows = []
    drift_rows = [int(absolute_rows[step]) for step in drift_steps if step < len(absolute_rows)]
    used_drifts: set[int] = set()

    for event_index, switch in enumerate(switch_rows, start=1):
        candidates = [
            (drift_index, row - switch)
            for drift_index, row in enumerate(drift_rows)
            if drift_index not in used_drifts
            and 0 <= row - switch < detection_window
        ]
        if candidates:
            drift_index, delay = min(candidates, key=lambda item: item[1])
            used_drifts.add(drift_index)
            detected = True
        else:
            delay = None
            detected = False
        event_rows.append(
            {
                "dataset": dataset,
                "seed": seed,
                "switch_index": event_index,
                "switch_row": int(switch),
                "detected": detected,
                "detection_delay_hours": delay,
            }
        )

    false_drifts = len(set(range(len(drift_rows))) - used_drifts)
    valid_delays = [
        row["detection_delay_hours"]
        for row in event_rows
        if row["detection_delay_hours"] is not None
    ]
    summary = {
        "dataset": dataset,
        "seed": seed,
        "true_switches": len(switch_rows),
        "drift_events": len(drift_rows),
        "detected_switches": sum(1 for row in event_rows if row["detected"]),
        "missed_switches": sum(1 for row in event_rows if not row["detected"]),
        "false_drifts": false_drifts,
        "median_detection_delay_hours": float(np.median(valid_delays)) if valid_delays else float("nan"),
    }
    return event_rows, summary


def run_component_and_boundary_analysis() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    metric_rows = []
    audit_rows = []
    boundary_rows = []
    detection_rows = []
    detection_event_rows = []

    for dataset in DATASETS:
        print(f"Reviewer-3 component analysis: {dataset}", flush=True)
        data, switch_rows = load_variant(dataset)

        for seed in SENSITIVITY_SEEDS:
            print(f"  component seed {seed}", flush=True)
            split = prepare_split(data)
            split["embedding"] = rpa_features(split["xs"], seed=seed)
            split["gate"] = choose_gate(split)
            test_idx = split["test_idx"]
            y_true = split["target"][test_idx]
            absolute_rows = test_idx + LOOKBACK + HORIZON - 1

            static_pred = static_predictions(split)
            zero_error = static_pred - y_true
            static_metrics = {
                "RMSE": math.sqrt(float(np.mean(zero_error**2))),
                "MAE": float(np.mean(np.abs(zero_error))),
                "MASE": float(np.mean(np.abs(zero_error)) / split["mase_den"]),
            }
            metric_rows.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "model": "Static RPA (gated)",
                    **static_metrics,
                }
            )
            boundary_rows.extend(
                boundary_metrics(
                    dataset, seed, "Static RPA (gated)", static_pred, y_true, absolute_rows, switch_rows
                )
            )

            combined_metrics, combined_audit, combined_pred, drift_steps, periodic_steps = simulate_general(
                split, "combined"
            )
            target_budget = int(combined_audit["gradient_samples"])
            variants = {
                "AE-RPA combined": (combined_metrics, combined_audit, combined_pred, drift_steps, periodic_steps)
            }

            for label, mode in [
                ("Local-update-only", "local"),
                ("Periodic-refresh-only", "periodic"),
                ("Drift-refresh-only", "drift"),
            ]:
                variants[label] = simulate_general(
                    split, mode, target_budget=target_budget
                )

            for label, values in variants.items():
                metrics, audit, prediction, seed_drift_steps, seed_periodic_steps = values
                metric_rows.append(
                    {"dataset": dataset, "seed": seed, "model": label, **metrics}
                )
                audit_rows.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "model": label,
                        **audit,
                        "periodic_events_observed": len(seed_periodic_steps),
                    }
                )
                boundary_rows.extend(
                    boundary_metrics(dataset, seed, label, prediction, y_true, absolute_rows, switch_rows)
                )

            events, summary = detection_diagnostics(
                dataset,
                seed,
                drift_steps,
                absolute_rows,
                switch_rows,
            )
            detection_event_rows.extend(events)
            detection_rows.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    **summary,
                }
            )

    metrics_df = pd.DataFrame(metric_rows)
    audit_df = pd.DataFrame(audit_rows)
    boundary_df = pd.DataFrame(boundary_rows)
    detection_df = pd.DataFrame(detection_rows)

    statistics_rows = []
    for dataset, group in metrics_df.groupby("dataset"):
        pivot = group.pivot(index="seed", columns="model", values="RMSE")
        combined = pivot["AE-RPA combined"]
        for comparator in ["Local-update-only", "Periodic-refresh-only", "Drift-refresh-only", "Static RPA (gated)"]:
            statistics_rows.append(
                paired_statistics(
                    dataset,
                    f"AE-RPA combined minus {comparator}",
                    combined.values,
                    pivot[comparator].values,
                    "reviewer3-component",
                )
            )
    component_stats = pd.DataFrame(statistics_rows)

    metrics_df.to_csv(RESDIR / "reviewer3_component_metrics_by_seed.csv", index=False)
    audit_df.to_csv(RESDIR / "reviewer3_component_audit.csv", index=False)
    boundary_df.to_csv(RESDIR / "reviewer3_boundary_metrics_by_seed.csv", index=False)
    detection_df.to_csv(RESDIR / "reviewer3_detection_summary_by_seed.csv", index=False)
    pd.DataFrame(detection_event_rows).to_csv(RESDIR / "reviewer3_detection_events.csv", index=False)
    component_stats.to_csv(RESDIR / "reviewer3_component_statistical_tests.csv", index=False)

    component_summary = (
        metrics_df.groupby(["dataset", "model"], as_index=False)
        .agg(
            RMSE_mean=("RMSE", "mean"),
            RMSE_std=("RMSE", lambda values: values.std(ddof=1)),
            MAE_mean=("MAE", "mean"),
            MASE_mean=("MASE", "mean"),
        )
        .sort_values(["dataset", "RMSE_mean"])
    )
    boundary_summary = (
        boundary_df.groupby(["dataset", "model", "window_hours"], as_index=False)
        .agg(
            pre_rmse_mean=("pre_rmse", "mean"),
            post_rmse_mean=("post_rmse", "mean"),
            delta_mean=("post_minus_pre", "mean"),
            delta_std=("post_minus_pre", lambda values: values.std(ddof=1)),
        )
        .sort_values(["dataset", "window_hours", "model"])
    )
    component_summary.to_csv(RESDIR / "reviewer3_component_summary.csv", index=False)
    boundary_summary.to_csv(RESDIR / "reviewer3_boundary_summary.csv", index=False)
    return component_summary, component_stats, boundary_summary, detection_df


def run_sensitivity_analysis() -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    state = {}

    for dataset in DATASETS:
        print(f"Reviewer-3 sensitivity: {dataset}", flush=True)
        default_data, _ = load_variant(dataset)
        for seed in SENSITIVITY_SEEDS:
            split = prepare_split(default_data)
            split["embedding"] = rpa_features(split["xs"], seed=seed)
            split["gate"] = choose_gate(split)
            state[(dataset, seed)] = split

            for multiplier in PH_MULTIPLIERS:
                metrics, audit, _, _, _ = simulate_general(
                    split, "combined", ph_multiplier=multiplier
                )
                rows.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "experiment": "PH threshold multiplier",
                        "model": "AE-RPA combined",
                        "setting": f"{multiplier:g} SD",
                        **metrics,
                        "drift_events": audit["drift_events"],
                    }
                )

            for cooldown in COOLDOWNS:
                metrics, audit, _, _, _ = simulate_general(
                    split, "combined", cooldown_hours=cooldown
                )
                rows.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "experiment": "Cooldown hours",
                        "model": "AE-RPA combined",
                        "setting": f"{cooldown} h",
                        **metrics,
                        "drift_events": audit["drift_events"],
                    }
                )

    for interval in SWITCH_INTERVALS:
        for dataset in DATASETS:
            print(f"Reviewer-3 switch interval {interval} h: {dataset}", flush=True)
            data, _ = load_variant(
                dataset,
                switch_block_hours=interval,
                controlled_interval_hours=interval,
            )
            for seed in SENSITIVITY_SEEDS:
                split = prepare_split(data)
                split["embedding"] = rpa_features(split["xs"], seed=seed)
                split["gate"] = choose_gate(split)
                static_pred = static_predictions(split)
                y_true = split["target"][split["test_idx"]]
                static_error = static_pred - y_true
                rows.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "experiment": "Regime-switch interval",
                        "model": "Static RPA (gated)",
                        "setting": f"{interval} h",
                        "RMSE": math.sqrt(float(np.mean(static_error**2))),
                        "MAE": float(np.mean(np.abs(static_error))),
                        "MASE": float(np.mean(np.abs(static_error)) / split["mase_den"]),
                        "drift_events": 0,
                    }
                )
                metrics, audit, _, _, _ = simulate_general(split, "combined")
                rows.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "experiment": "Regime-switch interval",
                        "model": "AE-RPA combined",
                        "setting": f"{interval} h",
                        **metrics,
                        "drift_events": audit["drift_events"],
                    }
                )

    sensitivity_by_seed = pd.DataFrame(rows)
    summary = (
        sensitivity_by_seed.groupby(["dataset", "experiment", "model", "setting"], as_index=False)
        .agg(
            RMSE_mean=("RMSE", "mean"),
            RMSE_std=("RMSE", lambda values: values.std(ddof=1)),
            MAE_mean=("MAE", "mean"),
            drift_events_mean=("drift_events", "mean"),
            n_seeds=("seed", "nunique"),
        )
        .sort_values(["dataset", "experiment", "model", "setting"])
    )
    sensitivity_by_seed.to_csv(RESDIR / "reviewer3_sensitivity_by_seed.csv", index=False)
    summary.to_csv(RESDIR / "reviewer3_sensitivity_summary.csv", index=False)
    return sensitivity_by_seed, summary


def measure_seconds(function, repeats: int) -> list[float]:
    for _ in range(3):
        function()
    values = []
    for _ in range(repeats):
        started = time.perf_counter()
        function()
        values.append(time.perf_counter() - started)
    return values


def runtime_and_resource_analysis() -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(20261110)
    embedding = rng.normal(size=(4096, 48)).astype("float32")
    adapter = rng.normal(size=48).astype("float32")
    intercept = np.float32(0.1)
    local_x = rng.normal(size=(1, 48)).astype("float32")
    local_y = rng.normal(size=(1,)).astype("float32")
    cloud_x = rng.normal(size=(384, 48)).astype("float32")
    cloud_y = rng.normal(size=(384,)).astype("float32")
    raw_windows = rng.normal(size=(256, LOOKBACK, 13)).astype("float32")

    def adapter_inference() -> None:
        _ = embedding @ adapter + intercept

    def local_update() -> None:
        _ = sgd_update(adapter.copy(), float(intercept), local_x, local_y)

    def cloud_update() -> None:
        _ = sgd_update(adapter.copy(), float(intercept), cloud_x, cloud_y)

    def feature_extraction() -> None:
        _ = rpa_features(raw_windows, seed=42)

    timing_rows = []
    for label, function, repeats, per_call in [
        ("Adapter inference per window", adapter_inference, 7, len(embedding)),
        ("Local SGD update per released sample", local_update, 15, 1),
        ("Cloud update over 384 replay samples", cloud_update, 15, 1),
        ("RPA feature extraction per 256-window batch", feature_extraction, 7, len(raw_windows)),
    ]:
        samples_ms = np.asarray(measure_seconds(function, repeats)) * 1000.0
        per_unit = samples_ms / per_call
        timing_rows.append(
            {
                "operation": label,
                "batch_size": per_call,
                "median_ms": float(np.median(samples_ms)),
                "p95_ms": float(np.percentile(samples_ms, 95)),
                "per_unit_ms": float(np.median(per_unit)),
                "repeats": repeats,
                "environment": "Python CPU software proxy",
            }
        )

    gc.collect()
    rss_before = None
    if psutil is not None:
        process = psutil.Process()
        rss_before = process.memory_info().rss
    tracemalloc.start()
    retained = rpa_features(raw_windows, seed=42)
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    rss_delta = "unavailable"
    if psutil is not None:
        rss_after = process.memory_info().rss
        rss_delta = str(rss_after - rss_before)
    timing_rows.append(
        {
            "operation": "RPA batch memory proxy (retained output)",
            "batch_size": len(raw_windows),
            "median_ms": float("nan"),
            "p95_ms": float("nan"),
            "per_unit_ms": float("nan"),
            "repeats": 1,
            "environment": f"tracemalloc_current={current}; peak={peak}; rss_delta={rss_delta}",
        }
    )
    pd.DataFrame(timing_rows).to_csv(RESDIR / "reviewer3_runtime_benchmark.csv", index=False)
    del retained

    fixed_projection_floats = 13 * D_MODEL + 3 * D_MODEL * D_MODEL
    fixed_position_floats = LOOKBACK * D_MODEL
    edge_resources = [
        {
            "component": "Adapter parameters (48 coefficients + intercept)",
            "bytes": 49 * 4,
            "description": "float32 cloud-to-edge return payload",
        },
        {
            "component": "Fixed random projection and attention matrices",
            "bytes": fixed_projection_floats * 4,
            "description": "W_in, W_q, W_k, and W_v",
        },
        {
            "component": "Fixed positional embedding",
            "bytes": fixed_position_floats * 4,
            "description": "24 x 16 float32 values",
        },
        {
            "component": "Current raw 24 h measured window",
            "bytes": LOOKBACK * 7 * 4,
            "description": "seven measured variables retained locally",
        },
        {
            "component": "Processed 24 h feature window",
            "bytes": LOOKBACK * 13 * 4,
            "description": "measured variables plus six cyclical time features",
        },
        {
            "component": "Maximum replay buffer",
            "bytes": REPLAY_CAP * 48 * 4,
            "description": "384 compact 48-float embeddings",
        },
        {
            "component": "Total persistent edge buffer estimate",
            "bytes": (49 + fixed_projection_floats + fixed_position_floats + LOOKBACK * 7 + REPLAY_CAP * 48) * 4,
            "description": "Adapter, fixed encoder, current raw window, and replay buffer",
        },
    ]
    resource_df = pd.DataFrame(edge_resources)
    resource_df["KiB"] = resource_df.bytes / 1024
    resource_df.to_csv(RESDIR / "reviewer3_resource_budget.csv", index=False)
    return pd.DataFrame(timing_rows), resource_df


def normalize_detection_summary(detection_df: pd.DataFrame) -> None:
    summary = (
        detection_df.groupby("dataset", as_index=False)
        .agg(
            true_switches_mean=("true_switches", "mean"),
            drift_events_mean=("drift_events", "mean"),
            detected_switches_mean=("detected_switches", "mean"),
            missed_switches_mean=("missed_switches", "mean"),
            false_drifts_mean=("false_drifts", "mean"),
            median_detection_delay_hours=("median_detection_delay_hours", "mean"),
        )
    )
    summary["detection_rate"] = (
        summary.detected_switches_mean / summary.true_switches_mean
    )
    summary.to_csv(RESDIR / "reviewer3_detection_summary.csv", index=False)


def main() -> None:
    print("Computing primary and control paired statistics", flush=True)
    make_statistical_tables()
    print("Running component and boundary analyses", flush=True)
    _, _, _, detection_df = run_component_and_boundary_analysis()
    normalize_detection_summary(detection_df)
    print("Running one-factor sensitivity analyses", flush=True)
    run_sensitivity_analysis()
    print("Running runtime and resource measurements", flush=True)
    runtime_and_resource_analysis()

    manifest = {
        "sensitivity_seeds": SENSITIVITY_SEEDS,
        "boundary_windows_hours": BOUNDARY_WINDOWS,
        "ph_multipliers": PH_MULTIPLIERS,
        "cooldowns_hours": COOLDOWNS,
        "switch_intervals_hours": SWITCH_INTERVALS,
        "runtime_environment": {
            "python": os.sys.version,
            "platform": os.sys.platform,
            "processor": os.environ.get("PROCESSOR_IDENTIFIER", "unknown"),
        },
        "note": (
            "Runtime values are software-environment proxies and are not presented "
            "as embedded-hardware measurements."
        ),
    }
    with open(RESDIR / "reviewer3_analysis_manifest.json", "w", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2)
    print("Reviewer-3 analysis complete", flush=True)


if __name__ == "__main__":
    main()
