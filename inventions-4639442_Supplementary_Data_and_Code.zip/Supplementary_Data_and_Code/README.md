# Supplementary Data and Code

## Article
**Evaluating Cloud–Edge Model Evolution for Distribution-Transformer Oil-Temperature Forecasting Across Stable and Regime-Shifted ETT Traces**

Target journal: *Inventions* (MDPI)

Public repository: https://github.com/Summer-LiuXP/inventions-4639442-supplementary

## Package contents

- `ETTh1.csv` — public ETTh1 trace used in the experiments.
- `ETTh2.csv` — public ETTh2 trace used in the experiments.
- `ETTm1.csv` — public ETTm1 trace used in the experiments.
- `run_experiment.py` — reproducible experiment script.
- `run_reviewer2_controls.py` — reproducible budget-matched ablations with local-update-only, periodic-refresh-only, and drift-refresh-only controls.
- `run_reviewer3_analyses.py` — five-seed component, boundary, detection, sensitivity, runtime, and memory analyses.
- `augment_reviewer3_summary.py` — adds paired confidence intervals and boundary comparisons to the Reviewer 3 result tables.
- `results/` — generated metric tables, prediction traces, statistical tests, communication summaries, robustness analyses, and `summary.json`.
- `results/reviewer2_*.csv` — control metrics, matched-budget audits, and paired significance tests requested by Reviewer 2.
- `results/reviewer3_*.csv` — component, boundary, detection, sensitivity, runtime, resource, and paired statistical outputs requested for Reviewer 3.
- `figures/` — figures generated from the implemented experiment artifact.

The semi-real `ETTSwitch` trace is constructed inside `run_experiment.py` from measured ETTh1 and ETTh2 segments. The controlled recurring-drift trace is generated synthetically inside the same script.

## Reproducing the experiments

From this directory, run:

```bash
python run_experiment.py
```

After the main run finishes, recreate the Reviewer 2 controls with:

```bash
python run_reviewer2_controls.py
```

Then run the Reviewer 3 robustness analyses and their confidence-interval extension:

```bash
python run_reviewer3_analyses.py
python augment_reviewer3_summary.py
```

Main Python dependencies used by the script are:

- numpy
- pandas
- matplotlib
- scikit-learn
- scipy

The script recreates the result tables and figures in the `results/` and `figures/` directories.

The control script writes seed-level metrics, an audit of local/cloud/equalizer gradient samples, summary tables, and paired two-sided tests against combined AE-RPA. Every control receives the same total gradient-example budget as combined AE-RPA for the corresponding seed.

The Reviewer 3 script uses five representative seeds, 1, 42, 89, 202, and 303, for component and one-factor sensitivity analyses. It reports means, standard deviations, paired 95% confidence intervals, Cohen's d_z, paired t tests, and two-sided Wilcoxon tests where seed-matched comparison is defined. The output also contains post-switch boundary errors for 24, 48, and 168 h windows, Page-Hinkley detection diagnostics, switch-interval sensitivity, and CPU runtime and memory proxies.

Runtime measurements were collected in a Python 3.12 CPU environment. They are software proxies, not embedded-edge or packet-level measurements. The 78.16 KiB persistent-buffer figure is an arithmetic float32 estimate and excludes interpreter and container overhead.

## Data provenance

ETTh1, ETTh2, and ETTm1 are public ETT datasets associated with the Informer/ETDataset project. Users reusing these data should cite the original source:

Zhou, H.; Zhang, S.; Peng, J.; Zhang, S.; Li, J.; Xiong, H.; Zhang, W.  
“Informer: Beyond Efficient Transformer for Long Sequence Time-Series Forecasting.”  
AAAI Conference on Artificial Intelligence, 2021, 35, 11106–11115.  
DOI: 10.1609/aaai.v35i12.17325

ETDataset repository: https://github.com/zhouhaoyi/ETDataset

## Scope

This supplementary package contains public datasets, experiment code, generated result tables, and figures required to reproduce the reported benchmark. It contains no proprietary utility data, manuscript source files, journal template files, or reviewer-response documents.
