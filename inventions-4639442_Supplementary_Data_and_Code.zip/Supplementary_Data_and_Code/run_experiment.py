"""Round 3 reproducible benchmark package.

This script expands the Round 2 ETTh1-only study to three public transformer
traces (ETTh1, ETTh2, ETTm1 down-sampled to hourly for CPU-reproducible 24 h
windows), adds zlib compression accounting, and includes a clearly labeled
controlled-drift stress test. No proprietary utility data are used.
"""
from pathlib import Path
import json, math, warnings, zlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.stats import ttest_rel
warnings.filterwarnings('ignore')
ROOT = Path(__file__).resolve().parent
FIGDIR = ROOT / 'figures'; RESDIR = ROOT / 'results'
FIGDIR.mkdir(parents=True, exist_ok=True); RESDIR.mkdir(parents=True, exist_ok=True)
LOOKBACK, HORIZON = 24, 24
SEEDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 29, 42, 61, 89, 101, 202, 303]
GATE_GRID = np.linspace(0, 1, 21)
RAW_MEASURED_VARIABLES = 7
D_MODEL = 16
BASE_COLS = ['HUFL','HULL','MUFL','MULL','LUFL','LULL','OT']

def add_time_features(df):
    df = df.copy(); df['date'] = pd.to_datetime(df['date'])
    for name, vals, period in [('hour', df['date'].dt.hour.values, 24), ('dow', df['date'].dt.dayofweek.values, 7), ('doy', df['date'].dt.dayofyear.values, 366)]:
        df[f'{name}_sin'] = np.sin(2*np.pi*vals/period); df[f'{name}_cos'] = np.cos(2*np.pi*vals/period)
    return df

def make_controlled_drift(n=12000, seed=7):
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    date = pd.date_range('2016-01-01', periods=n, freq='H')
    daily = np.sin(2*np.pi*t/24); weekly = np.cos(2*np.pi*t/(24*7)); slow = np.sin(2*np.pi*t/(24*60))
    signal = daily + 0.6*weekly + 0.25*rng.normal(size=n)
    # Training and validation are dominated by regime +1. The final test period alternates
    # between +1 and -1 every 21 days to stress delayed online adaptation.
    split_a = int(n*0.80)
    regime = np.ones(n)
    for st in range(split_a, n, 24*21):
        regime[st:st+24*21] = 1 if ((st-split_a)//(24*21)) % 2 == 0 else -1
    hu = signal + 0.15*rng.normal(size=n); mu = 0.7*signal + 0.4*slow + 0.15*rng.normal(size=n); lu = -0.5*signal + 0.3*weekly + 0.15*rng.normal(size=n)
    base = 12 + 1.3*slow + 0.2*weekly
    ot = base + 0.35*np.roll(base, 24) + 1.9*regime*np.roll(signal, 24) + 0.22*rng.normal(size=n)
    # Make the first day safe after roll.
    ot[:24] = base[:24] + 1.9*signal[:24] + 0.22*rng.normal(size=24)
    df = pd.DataFrame({'date':date,'HUFL':hu,'HULL':hu*0.45+0.1*rng.normal(size=n),'MUFL':mu,'MULL':mu*0.45+0.1*rng.normal(size=n),'LUFL':lu,'LULL':lu*0.45+0.1*rng.normal(size=n),'OT':ot.astype('float32')})
    return df

def load_dataset(name):
    if name == 'ControlledDrift':
        df = make_controlled_drift()
        note = 'controlled synthetic recurring-drift stress test; not field data'
    elif name == 'ETTSwitch':
        # Semi-real stress test built only from public ETTh1/ETTh2 measurements.
        # The first 80% is ETTh1. The final 20% alternates one-week blocks
        # from ETTh2 and ETTh1 to emulate public, station-level recurring domain
        # switches without inventing target values. Dates are reassigned to form
        # one chronological stream; all measured values come from ETDataset.
        h1 = pd.read_csv(ROOT / 'ETTh1.csv')
        h2 = pd.read_csv(ROOT / 'ETTh2.csv')
        total = min(16000, len(h1), len(h2))
        prefix = int(total * 0.80)
        block = 24 * 7
        parts = [h1.iloc[:prefix].copy()]
        pos1 = prefix
        pos2 = prefix
        while sum(len(p) for p in parts) < total:
            cur_len = sum(len(p) for p in parts)
            if ((cur_len - prefix) // block) % 2 == 0:
                seg = h2.iloc[pos2:pos2 + block].copy(); pos2 += block
            else:
                seg = h1.iloc[pos1:pos1 + block].copy(); pos1 += block
            if len(seg) == 0:
                break
            parts.append(seg)
        df = pd.concat(parts, ignore_index=True).iloc[:total].copy()
        df['date'] = pd.date_range('2016-01-01', periods=len(df), freq='h')
        note = 'semi-real public ETT station-switch stress test built from measured ETTh1/ETTh2 segments'
    else:
        df = pd.read_csv(ROOT / f'{name}.csv')
        note = 'public ETDataset trace'
        if name == 'ETTm1':
            df = df.iloc[1::4].reset_index(drop=True)
            note = 'public ETTm1 trace sampled at a 15-minute offset every hour for the CPU-reproducible 24 h protocol'
    df = add_time_features(df)
    time_cols = ['hour_sin','hour_cos','dow_sin','dow_cos','doy_sin','doy_cos']
    cols = BASE_COLS + time_cols
    rawX = df[cols].values.astype('float32'); raw_meas = df[BASE_COLS].values.astype('float32'); rawy = df['OT'].values.astype('float32')
    Xs=[]; Xraw=[]; ys=[]; yl=[]; dates=[]
    for i in range(len(df)-LOOKBACK-HORIZON+1):
        Xs.append(rawX[i:i+LOOKBACK]); Xraw.append(raw_meas[i:i+LOOKBACK]); ys.append(rawy[i+LOOKBACK+HORIZON-1]); yl.append(rawy[i+LOOKBACK-1]); dates.append(df['date'].iloc[i+LOOKBACK+HORIZON-1])
    return {'name':name, 'note':note, 'df':df, 'feature_cols':cols, 'X':np.stack(Xs), 'X_raw_measured':np.stack(Xraw), 'y':np.asarray(ys,dtype='float32'), 'y_last':np.asarray(yl,dtype='float32'), 'dates':pd.to_datetime(pd.Series(dates))}

def softmax(a, axis=-1):
    a = a - np.max(a, axis=axis, keepdims=True); ea=np.exp(a); return ea/np.sum(ea,axis=axis,keepdims=True)

def rpa_features(Xseq, d_model=D_MODEL, seed=42, chunk=4096):
    """Fixed random-projection attention with a last-token query.

    This is intentionally compact: only the final token queries the historical keys.
    It retains an attention-weighted temporal summary while avoiding the full L x L
    self-attention cost, which keeps the artifact CPU-reproducible.
    """
    rng=np.random.default_rng(seed); nf=Xseq.shape[-1]
    Win=rng.normal(0,1/math.sqrt(nf),size=(nf,d_model)).astype('float32')
    Wq=rng.normal(0,1/math.sqrt(d_model),size=(d_model,d_model)).astype('float32')
    Wk=rng.normal(0,1/math.sqrt(d_model),size=(d_model,d_model)).astype('float32')
    Wv=rng.normal(0,1/math.sqrt(d_model),size=(d_model,d_model)).astype('float32')
    pos=np.arange(Xseq.shape[1])[:,None].astype('float32'); div=np.exp(np.arange(0,d_model,2).astype('float32')*(-math.log(10000.0)/d_model))
    pe=np.zeros((Xseq.shape[1],d_model),dtype='float32'); pe[:,0::2]=np.sin(pos*div); pe[:,1::2]=np.cos(pos*div)
    out=[]
    for st in range(0,len(Xseq),chunk):
        z=Xseq[st:st+chunk]@Win + pe[None,:,:]
        q=z[:,-1,:]@Wq
        k=z@Wk; v=z@Wv
        scores=np.einsum('bd,bld->bl',q,k)/math.sqrt(d_model)
        a=softmax(scores,axis=1)
        h=np.einsum('bl,bld->bd',a,v)
        out.append(np.concatenate([h,v.mean(axis=1),v.std(axis=1)],axis=1).astype('float32'))
    return np.vstack(out)

def dlinear_features(Xseq, kernel=5):
    pad=kernel//2; padded=np.pad(Xseq,((0,0),(pad,pad),(0,0)),mode='edge'); trend=np.zeros_like(Xseq,dtype='float32')
    for j in range(kernel): trend += padded[:,j:j+Xseq.shape[1],:]
    trend /= float(kernel); seasonal = Xseq-trend
    return np.concatenate([trend[:,-1,:], trend.mean(axis=1), seasonal[:,-1,:], seasonal.mean(axis=1), seasonal.std(axis=1), Xseq[:,-1,:]], axis=1).astype('float32')

def zbytes(arr):
    return len(zlib.compress(np.ascontiguousarray(arr.astype('float32')).tobytes(), level=6))

def run_one_dataset(data, seeds=SEEDS):
    X=data['X']; Xraw=data['X_raw_measured']; y=data['y']; y_last=data['y_last']; n=len(X)
    n_train=int(n*.60); n_val=int(n*.20); train_idx=np.arange(n_train); val_idx=np.arange(n_train,n_train+n_val); test_idx=np.arange(n_train+n_val,n); train_fit_idx=train_idx[::2]
    feat_scaler=StandardScaler().fit(X[train_idx].reshape(-1,X.shape[-1])); y_scaler=StandardScaler().fit(y[train_idx].reshape(-1,1))
    Xs=feat_scaler.transform(X.reshape(-1,X.shape[-1])).reshape(X.shape).astype('float32')
    ys=y_scaler.transform(y.reshape(-1,1)).ravel().astype('float32'); yls=y_scaler.transform(y_last.reshape(-1,1)).ravel().astype('float32'); resid=(ys-yls).astype('float32')
    Xf=Xs.reshape(n,-1).astype('float32')
    raw=data['df']['OT'].values.astype('float32')
    mase_den=float(np.maximum(np.mean(np.abs(raw[HORIZON:n_train+LOOKBACK+HORIZON]-raw[:n_train+LOOKBACK])),1e-6))
    yrange=float(np.max(y[train_idx])-np.min(y[train_idx]))
    def inv(z): return y_scaler.inverse_transform(np.asarray(z).reshape(-1,1)).ravel()
    def met(yt,yp):
        rmse=math.sqrt(mean_squared_error(yt,yp)); mae=mean_absolute_error(yt,yp)
        return {'RMSE':rmse,'MAE':mae,'MASE':mae/mase_den,'NRMSE':rmse/max(yrange,1e-6)}
    def choose_gate(val_resid, idx=val_idx):
        scores=[mean_squared_error(y[idx], inv(yls[idx]+a*val_resid)) for a in GATE_GRID]
        j=int(np.argmin(scores)); return float(GATE_GRID[j]), float(scores[j])
    def gated(resid_pred, idx, gate): return inv(yls[idx]+gate*resid_pred)
    def ridge(feat, alpha=1.0): return Ridge(alpha=alpha, solver='cholesky').fit(feat[train_fit_idx], resid[train_fit_idx])
    def params(model): return model.coef_.astype('float32').copy(), float(model.intercept_)
    def sgd_update(w,b,Xb,yb,eta=0.002,l2=1e-4):
        Xb=np.asarray(Xb,dtype='float32'); yb=np.asarray(yb,dtype='float32'); pred=Xb@w+b; err=pred-yb
        w=w - eta*(((Xb.T@err)/len(yb)+l2*w).astype('float32')); b=float(b - eta*float(np.mean(err)))
        return w.astype('float32'), b
    def delayed_online(feat, init_model, gate, eta=0.002):
        w,b=params(init_model); q=[]; yh=[]; updates=0
        for idx in test_idx:
            yh.append(yls[idx]+gate*float(feat[idx]@w+b)); q.append((feat[idx], resid[idx]))
            if len(q)>HORIZON:
                xb,yb=q.pop(0); w,b=sgd_update(w,b,xb.reshape(1,-1),np.array([yb]),eta=eta); updates+=1
        return inv(yh), updates
    def online_residual_stream(feat, init_model, stream_idx, eta=0.002):
        w,b=params(init_model); q=[]; out=[]
        for idx in stream_idx:
            out.append(float(feat[idx]@w+b)); q.append((feat[idx], resid[idx]))
            if len(q)>HORIZON:
                xb,yb=q.pop(0); w,b=sgd_update(w,b,xb.reshape(1,-1),np.array([yb]),eta=eta)
        return np.asarray(out, dtype='float32')
    def select_online_eta(feat, init_model):
        best=None
        for eta in [0.0, 0.00005, 0.0001, 0.0002, 0.0005, 0.001, 0.002]:
            val_pred=online_residual_stream(feat, init_model, val_idx, eta=eta)
            g,score=choose_gate(val_pred, val_idx)
            if best is None or score < best[0]: best=(score, eta, g)
        pred, updates=delayed_online(feat, init_model, best[2], eta=best[1])
        return pred, {'eta':best[1], 'gate':best[2], 'validation_mse':best[0], 'updates':updates}
    def fast_slow(feat, slow_model, eta=0.002):
        slow_val=slow_model.predict(feat[val_idx]); w0,b0=params(slow_model); w,b=w0.copy(),b0; q=[]; fast_val=[]
        for idx in val_idx:
            fast_val.append(float(feat[idx]@w+b)); q.append((feat[idx],resid[idx]))
            if len(q)>HORIZON:
                xb,yb=q.pop(0); w,b=sgd_update(w,b,xb.reshape(1,-1),np.array([yb]),eta=eta)
        best=None
        for wf in np.linspace(0,1,11):
            mix=wf*np.asarray(fast_val)+(1-wf)*slow_val; g,score=choose_gate(mix,val_idx)
            if best is None or score<best[0]: best=(score,float(wf),g)
        wf,g=best[1],best[2]; w,b=w0.copy(),b0; q=[]; yh=[]; updates=0; slow_test=slow_model.predict(feat[test_idx])
        for step,idx in enumerate(test_idx):
            fast=float(feat[idx]@w+b); yh.append(yls[idx]+g*(wf*fast+(1-wf)*slow_test[step])); q.append((feat[idx],resid[idx]))
            if len(q)>HORIZON:
                xb,yb=q.pop(0); w,b=sgd_update(w,b,xb.reshape(1,-1),np.array([yb]),eta=eta); updates+=1
        return inv(yh), {'mixture_w_fast':wf,'gate':g,'updates':updates}
    def ae_rpa(feat, init_model, eta=0.00025):
        w,b=params(init_model); val_resid=init_model.predict(feat[val_idx]); gate,_=choose_gate(val_resid)
        val_err=np.abs(val_resid-resid[val_idx]); ph_mean=float(val_err.mean()); ph_lambda=float(ph_mean+5*val_err.std()+1e-6)
        q=[]; RX=[]; RY=[]; RRAW=[]; yh=[]; yh1=[]; drifts=[]; grad=0; distinct=0; compact=0; rawb=0; zraw=0; zcompact=0; cum=0.0; mincum=0.0; mean_e=ph_mean; last=-10**9; event_counts=[]
        for step,idx in enumerate(test_idx):
            rp=float(feat[idx]@w+b); yh.append(yls[idx]+gate*rp); yh1.append(yls[idx]+rp); q.append((feat[idx],resid[idx],Xraw[idx]))
            if len(q)>HORIZON:
                xb,yb,xr=q.pop(0); err=abs(float(xb@w+b)-yb); RX.append(xb); RY.append(yb); RRAW.append(xr)
                if len(RX)>384: RX.pop(0); RY.pop(0); RRAW.pop(0)
                mean_e=.995*mean_e+.005*err; cum += err-mean_e-.01; mincum=min(mincum,cum)
                do_refresh = (cum-mincum>ph_lambda and len(RX)>128 and (step-last)>=168)
                do_periodic = (step>0 and step%(24*21)==0 and len(RX)>64)
                if do_refresh or do_periodic:
                    if do_refresh: drifts.append(step); last=step; cum=0.0; mincum=0.0
                    use_n = len(RX) if do_refresh else min(128, len(RX))
                    rX=np.asarray(RX[-use_n:],dtype='float32'); rY=np.asarray(RY[-use_n:],dtype='float32'); rRaw=np.asarray(RRAW[-use_n:],dtype='float32')
                    for _ in range(2): w,b=sgd_update(w,b,rX,rY,eta=eta,l2=5e-5); grad += len(rY)
                    compact += rX.size*4; rawb += rRaw.size*4; zcompact += zbytes(rX); zraw += zbytes(rRaw); event_counts.append(int(use_n))
                else:
                    w,b=sgd_update(w,b,xb.reshape(1,-1),np.array([yb]),eta=eta,l2=5e-5); grad+=1; distinct+=1
        stats={'gate':gate,'ph_threshold':ph_lambda,'num_drift_triggers':len(drifts),'drift_triggers':[int(s) for s in drifts], 'gradient_sample_updates':int(grad),'distinct_delayed_online_updates':int(distinct),'compact_upload_bytes':int(compact),'raw_measured_replay_upload_bytes':int(rawb),'compact_zlib_upload_bytes':int(zcompact),'raw_zlib_replay_upload_bytes':int(zraw),'compact_reduction_vs_raw_replay_percent':float(100*(1-compact/max(1,rawb))), 'compact_zlib_reduction_vs_raw_zlib_percent':float(100*(1-zcompact/max(1,zraw))), 'uncompressed_compact_vs_zlib_raw_percent':float(100*(1-compact/max(1,zraw))), 'event_replay_sample_counts':event_counts}
        return inv(yh), stats, inv(yh1)
    # deterministic/common baselines
    preds={}; meta={}
    preds['Persistence']=y_last[test_idx]
    base_ridge=ridge(Xf); bg,_=choose_gate(base_ridge.predict(Xf[val_idx])); preds['Residual Ridge-ARX (gated)']=gated(base_ridge.predict(Xf[test_idx]),test_idx,bg); meta['Residual Ridge-ARX (gated)']={'gate':bg}
    dfeat=dlinear_features(Xs); dsc=StandardScaler().fit(dfeat[train_idx]); dfeat=dsc.transform(dfeat).astype('float32'); dlin=ridge(dfeat); dg,_=choose_gate(dlin.predict(dfeat[val_idx])); preds['DLinear-style residual (gated)']=gated(dlin.predict(dfeat[test_idx]),test_idx,dg); meta['DLinear-style residual (gated)']={'gate':dg}
    od_pred,od_meta=select_online_eta(Xf,base_ridge); preds['Delayed online SGD residual']=od_pred; meta['Delayed online SGD residual']=od_meta
    fs_pred,fs_meta=fast_slow(Xf,base_ridge,eta=od_meta['eta']); fs_meta['eta']=od_meta['eta']; preds['Delayed fast-slow residual']=fs_pred; meta['Delayed fast-slow residual']=fs_meta
    rows=[]; seed_rows=[]; stats_by_seed=[]; preds_seed42=None; meta_seed42=None; feat_seed42=None; static_seed42=None
    for k,p in preds.items(): rows.append({'dataset':data['name'],'seed':0,'model':k,**met(y[test_idx],p)})
    for seed in seeds:
        emb=rpa_features(Xs,seed=seed); static=ridge(emb); sg,_=choose_gate(static.predict(emb[val_idx]))
        p_static=gated(static.predict(emb[test_idx]),test_idx,sg)
        p_static1=gated(static.predict(emb[test_idx]),test_idx,1.0)
        ae_pred,ae_stats,ae_one=ae_rpa(emb,static)
        seed_preds={'Static RPA observer (gated)':p_static,'Static RPA observer (ungated)':p_static1,'AE-RPA observer (gated)':ae_pred,'AE-RPA observer (lambda=1)':ae_one}
        for k,p in seed_preds.items(): seed_rows.append({'dataset':data['name'],'seed':seed,'model':k,**met(y[test_idx],p)})
        stats_by_seed.append({'dataset':data['name'],'seed':seed,'static_gate':sg,'ae':ae_stats})
        if seed==42:
            preds_seed42={**preds,**seed_preds}; meta_seed42={'static_gate':sg,'ae':ae_stats,'fast_slow':fs_meta}; feat_seed42=emb; static_seed42=static
    # summary rows combining deterministic and seed models
    det_df=pd.DataFrame(rows); stoch_df=pd.DataFrame(seed_rows); all_df=pd.concat([det_df,stoch_df],ignore_index=True)
    order=['Persistence','Residual Ridge-ARX (gated)','DLinear-style residual (gated)','Delayed online SGD residual','Delayed fast-slow residual','Static RPA observer (gated)','Static RPA observer (ungated)','AE-RPA observer (gated)','AE-RPA observer (lambda=1)']
    records=[]
    for m in order:
        sub=all_df[all_df['model']==m]
        for metric in ['RMSE','MAE','MASE','NRMSE']:
            pass
        records.append({'dataset':data['name'],'model':m, **{f'{metric}_mean':float(sub[metric].mean()) for metric in ['RMSE','MAE','MASE','NRMSE']}, **{f'{metric}_std':float(sub[metric].std(ddof=1) if len(sub)>1 else 0.0) for metric in ['RMSE','MAE','MASE','NRMSE']}})
    sum_df=pd.DataFrame(records)
    ae_rmse = stoch_df[stoch_df['model']=='AE-RPA observer (gated)'].sort_values('seed')['RMSE'].values
    st_rmse = stoch_df[stoch_df['model']=='Static RPA observer (gated)'].sort_values('seed')['RMSE'].values
    try:
        t_res=ttest_rel(ae_rmse, st_rmse)
        pval=float(t_res.pvalue)
    except Exception:
        pval=float('nan')
    # seed 42 predictions
    pred_df=pd.DataFrame({'dataset':data['name'],'date':data['dates'].iloc[test_idx].astype(str).values,'y_true':y[test_idx]})
    for k in order:
        if k in preds_seed42: pred_df[k]=preds_seed42[k]
    comm=pd.DataFrame([s['ae'] for s in stats_by_seed]); comm.insert(0,'seed',[s['seed'] for s in stats_by_seed]); comm.insert(0,'dataset',data['name'])
    summary={'dataset':data['name'],'note':data['note'],'n_samples':int(n),'train_samples':len(train_idx),'validation_samples':len(val_idx),'test_samples':len(test_idx),'lookback_hours':LOOKBACK,'forecast_horizon_hours':HORIZON,'feature_columns':data['feature_cols'],'best_model_by_rmse':str(sum_df.loc[sum_df['RMSE_mean'].idxmin(),'model']),'static_vs_ae_paired_pvalue':pval,'fast_slow_mixture_w_fast':float(fs_meta['mixture_w_fast']),'fast_slow_collapsed_to_slow':bool(fs_meta['mixture_w_fast']==0.0),'ae_mean_rmse':float(sum_df[sum_df.model=='AE-RPA observer (gated)']['RMSE_mean'].iloc[0]),'static_mean_rmse':float(sum_df[sum_df.model=='Static RPA observer (gated)']['RMSE_mean'].iloc[0]),'comm_mean':{c:float(comm[c].mean()) for c in ['compact_upload_bytes','raw_measured_replay_upload_bytes','compact_zlib_upload_bytes','raw_zlib_replay_upload_bytes','compact_reduction_vs_raw_replay_percent','compact_zlib_reduction_vs_raw_zlib_percent','uncompressed_compact_vs_zlib_raw_percent','num_drift_triggers']},'comm_std':{c:float(comm[c].std(ddof=1)) for c in ['compact_upload_bytes','raw_measured_replay_upload_bytes','compact_zlib_upload_bytes','raw_zlib_replay_upload_bytes','compact_reduction_vs_raw_replay_percent','compact_zlib_reduction_vs_raw_zlib_percent','uncompressed_compact_vs_zlib_raw_percent','num_drift_triggers']},'seed42_meta':meta_seed42}
    return {'all_metrics':all_df,'summary_metrics':sum_df,'predictions_seed42':pred_df,'comm_by_seed':comm,'summary':summary}

# Run datasets.
DATASETS=['ETTh1','ETTh2','ETTm1','ETTSwitch','ControlledDrift']
all_metrics=[]; summaries=[]; preds=[]; comms=[]; sum_json={}
for name in DATASETS:
    print('Running', name, flush=True)
    data=load_dataset(name)
    res=run_one_dataset(data)
    all_metrics.append(res['all_metrics']); summaries.append(res['summary_metrics']); preds.append(res['predictions_seed42']); comms.append(res['comm_by_seed']); sum_json[name]=res['summary']
all_metrics=pd.concat(all_metrics,ignore_index=True); summaries=pd.concat(summaries,ignore_index=True); preds=pd.concat(preds,ignore_index=True); comms=pd.concat(comms,ignore_index=True)
all_metrics.to_csv(RESDIR/'metrics_by_dataset_seed.csv',index=False)
summaries.to_csv(RESDIR/'metrics_summary_by_dataset.csv',index=False)
preds.to_csv(RESDIR/'predictions_seed42_by_dataset.csv',index=False)
comms.to_csv(RESDIR/'communication_by_dataset_seed.csv',index=False)
json.dump(sum_json, open(RESDIR/'summary.json','w'), indent=2)
# Derived cross-dataset summaries.
public=summaries[summaries.dataset.isin(['ETTh1','ETTh2','ETTm1','ETTSwitch'])]
comm_cols=['compact_upload_bytes','raw_measured_replay_upload_bytes','compact_zlib_upload_bytes','raw_zlib_replay_upload_bytes','compact_reduction_vs_raw_replay_percent','compact_zlib_reduction_vs_raw_zlib_percent','uncompressed_compact_vs_zlib_raw_percent','num_drift_triggers']
comm_summary=comms.groupby('dataset')[comm_cols].agg(['mean','std'])
comm_summary.columns=[f'{a}_{b}' for a,b in comm_summary.columns]; comm_summary.to_csv(RESDIR/'communication_summary_by_dataset.csv')
# Figures.
plt.rcParams.update({'font.size':9})
# Clean publication-style architecture figure.
fig,ax=plt.subplots(figsize=(8.0,4.8)); ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,6)
box_style=dict(boxstyle='round,pad=0.35', linewidth=1.2, facecolor='white')
boxes={
    'stream':(1.2,4.6,'Transformer-district stream\nmeasured variables + time'),
    'edge':(4.0,4.6,'Edge observer\n24 h window -> fixed RPA\nvalidation residual gate'),
    'output':(7.5,4.6,'Local output\n24 h-ahead OT forecast\nraw history kept local'),
    'queue':(4.0,2.8,'Delayed feedback queue\nlabel release after 24 h\nsmall edge update'),
    'monitor':(1.2,1.0,'Page-Hinkley monitor\nthreshold + cooldown\nperiodic guard'),
    'cloud':(7.5,1.0,'Cloud refresh service\ncompact replay adapter update\nparameter return')
}
for key,(x,y,text) in boxes.items():
    ax.text(x,y,text,ha='center',va='center',bbox=box_style,linespacing=1.25)
def arrow(a,b,label='',dx=0,dy=0):
    x1,y1,_=boxes[a]; x2,y2,_=boxes[b]
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='->',lw=1.25,shrinkA=28,shrinkB=28))
    if label:
        ax.text((x1+x2)/2+dx,(y1+y2)/2+dy,label,ha='center',va='center',fontsize=8)
arrow('stream','edge','window',0,0.35)
arrow('edge','output','forecast',0,0.35)
arrow('output','queue','delayed labels',0.55,0.0)
arrow('queue','monitor','released errors',-0.05,0.25)
arrow('monitor','cloud','refresh trigger',0,0.32)
arrow('cloud','edge','adapter parameters',0.65,0.0)
ax.text(5,5.65,'Cloud-edge observer with delayed feedback and compact replay',ha='center',va='center',fontsize=12,weight='bold')
ax.text(5,0.25,'All boxes correspond to implemented components in run_experiment.py; no placeholder figure elements are used.',ha='center',fontsize=8)
fig.tight_layout(); fig.savefig(FIGDIR/'architecture_round4.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/'architecture_round4.png',dpi=300,bbox_inches='tight'); plt.close(fig)
# public benchmark RMSE grouped
plot_models=['Persistence','Residual Ridge-ARX (gated)','DLinear-style residual (gated)','Static RPA observer (gated)','AE-RPA observer (gated)']
labels=['Pers.','Ridge','DLinear','Static RPA','AE-RPA']
datasets=['ETTh1','ETTh2','ETTm1','ETTSwitch']
fig,ax=plt.subplots(figsize=(7.6,4.4)); x=np.arange(len(datasets)); width=0.15
for j,m in enumerate(plot_models):
    sub=public[public.model==m].set_index('dataset').loc[datasets]
    ax.bar(x+(j-2)*width, sub['RMSE_mean'], width, yerr=sub['RMSE_std'], capsize=2, label=labels[j])
ax.set_xticks(x); ax.set_xticklabels(['ETTh1','ETTh2','ETTm1-hourly','ETT-switch'], rotation=10); ax.set_ylabel('RMSE of OT, deg C'); ax.set_title('Public ETT benchmark with fair residual baselines'); ax.grid(axis='y',alpha=.3); ax.legend(ncol=3,fontsize=7); fig.tight_layout(); fig.savefig(FIGDIR/'public_rmse_round4.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/'public_rmse_round4.png',dpi=300,bbox_inches='tight'); plt.close(fig)
# compression communication bars by dataset
fig,ax=plt.subplots(figsize=(7.8,4.1)); x=np.arange(len(datasets)); width=.25; cs=comm_summary.loc[datasets]
vals1=cs['compact_zlib_upload_bytes_mean'].values/1024/1024; vals2=cs['raw_zlib_replay_upload_bytes_mean'].values/1024/1024; vals3=cs['raw_measured_replay_upload_bytes_mean'].values/1024/1024
err1=cs['compact_zlib_upload_bytes_std'].values/1024/1024; err2=cs['raw_zlib_replay_upload_bytes_std'].values/1024/1024; err3=cs['raw_measured_replay_upload_bytes_std'].values/1024/1024
ax.bar(x-width, vals1, width, yerr=err1, capsize=2, label='Compact replay, zlib')
ax.bar(x, vals2, width, yerr=err2, capsize=2, label='Raw window replay, zlib')
ax.bar(x+width, vals3, width, yerr=err3, capsize=2, label='Raw window replay, float32')
ax.set_xticks(x); ax.set_xticklabels(['ETTh1','ETTh2','ETTm1-hourly','ETT-switch'], rotation=10); ax.set_ylabel('Refresh upload, MiB'); ax.set_title('Compression-controlled refresh communication accounting'); ax.grid(axis='y',alpha=.3); ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(FIGDIR/'communication_compression_round4.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/'communication_compression_round4.png',dpi=300,bbox_inches='tight'); plt.close(fig)
# controlled drift RMSE figure
ctrl=summaries[summaries.dataset=='ControlledDrift']; fig,ax=plt.subplots(figsize=(6.8,4.1)); cm=['Persistence','Residual Ridge-ARX (gated)','DLinear-style residual (gated)','Static RPA observer (gated)','AE-RPA observer (gated)']; sub=ctrl.set_index('model').loc[cm]
ax.bar(np.arange(len(cm)), sub['RMSE_mean'].values, yerr=sub['RMSE_std'].values, capsize=3)
ax.set_xticks(np.arange(len(cm))); ax.set_xticklabels(['Pers.','Ridge','DLinear','Static RPA','AE-RPA'],rotation=25,ha='right'); ax.set_ylabel('RMSE'); ax.set_title('Controlled recurring-drift stress test'); ax.grid(axis='y',alpha=.3)
for i,v in enumerate(sub['RMSE_mean'].values): ax.text(i,v+.02,f'{v:.2f}',ha='center',va='bottom',fontsize=8)
fig.tight_layout(); fig.savefig(FIGDIR/'controlled_drift_rmse_round4.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/'controlled_drift_rmse_round4.png',dpi=300,bbox_inches='tight'); plt.close(fig)
# rolling for ETTh2 and trace for controlled
for ds, fname, title in [('ETTh2','rolling_rmse_etth2_round4','Rolling RMSE on ETTh2 public trace'),('ControlledDrift','controlled_drift_trace_round4','Controlled-drift forecast trace')]:
    dfp=preds[preds.dataset==ds].reset_index(drop=True); yt=dfp['y_true'].values; dates=pd.to_datetime(dfp['date'])
    def rolling(yp,w=168): return pd.Series((np.asarray(yp)-yt)**2).rolling(w,min_periods=24).mean().pow(.5).values
    fig,ax=plt.subplots(figsize=(7.4,4.2))
    for k in ['Persistence','DLinear-style residual (gated)','Static RPA observer (gated)','AE-RPA observer (gated)']:
        ax.plot(dates, rolling(dfp[k].values), label=k, linewidth=1.05)
    ax.set_ylabel('Rolling RMSE (168 h)'); ax.set_xlabel('Test timestamp'); ax.set_title(title); ax.legend(fontsize=7); fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(FIGDIR/f'{fname}.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/f'{fname}.png',dpi=300,bbox_inches='tight'); plt.close(fig)
# representative prediction trace for ETTm1
for ds, fname in [('ETTm1','prediction_excerpt_ettm1_round4')]:
    dfp=preds[preds.dataset==ds].reset_index(drop=True); n=len(dfp); sl=slice(max(0,n//2-240), max(0,n//2-240)+480); dates=pd.to_datetime(dfp['date'].iloc[sl])
    fig,ax=plt.subplots(figsize=(7.4,4.2)); ax.plot(dates, dfp['y_true'].iloc[sl], label='Observed OT', linewidth=1.1)
    for k in ['Persistence','Static RPA observer (gated)','AE-RPA observer (gated)']:
        ax.plot(dates, dfp[k].iloc[sl], label=k, linewidth=1.0)
    ax.set_ylabel('Oil temperature, deg C'); ax.set_xlabel('Timestamp'); ax.set_title('Representative ETTm1-hourly 20-day forecast excerpt'); ax.legend(fontsize=7); fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(FIGDIR/f'{fname}.pdf',bbox_inches='tight'); fig.savefig(FIGDIR/f'{fname}.png',dpi=300,bbox_inches='tight'); plt.close(fig)
print(summaries.round(4).to_string(index=False))
print(comm_summary.round(4).to_string())
