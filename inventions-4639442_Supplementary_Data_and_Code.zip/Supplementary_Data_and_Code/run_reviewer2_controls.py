"""Reviewer-2 ablations for the AE-RPA cloud-edge evolution loop.

The script adds three update-budget-matched controls to the original package:

1. local-update-only;
2. periodic-refresh-only; and
3. drift-refresh-only.

All controls use the same fixed encoder, validation-selected residual gate,
delayed labels, optimizer, learning rate, replay capacity, and total number of
gradient-example updates as the combined AE-RPA run for the same seed. The two
reported stress traces are ETT-Switch and ControlledDrift.

The budget equalizer adds only local replay updates from already released
labels. It does not inspect future labels and does not alter the cloud refresh
mechanism being tested.
"""
from __future__ import annotations

import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import ttest_rel
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parent
RESDIR = ROOT / "results"
RESDIR.mkdir(parents=True, exist_ok=True)

LOOKBACK = 24
HORIZON = 24
SEEDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 29, 42, 61, 89, 101, 202, 303]
GATE_GRID = np.linspace(0.0, 1.0, 21)
D_MODEL = 16
BASE_COLS = ["HUFL", "HULL", "MUFL", "MULL", "LUFL", "LULL", "OT"]
REPLAY_CAP = 384
DRIFT_REPLAY_MIN = 128
PERIODIC_REPLAY_MIN = 64
COOLDOWN_HOURS = 168
PERIODIC_INTERVAL = 504
LOCAL_LR = 2.5e-4
L2 = 5e-5
BUDGET_CHECKPOINT = 24


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    for name, vals, period in [
        ("hour", df["date"].dt.hour.values, 24),
        ("dow", df["date"].dt.dayofweek.values, 7),
        ("doy", df["date"].dt.dayofyear.values, 366),
    ]:
        df[f"{name}_sin"] = np.sin(2 * np.pi * vals / period)
        df[f"{name}_cos"] = np.cos(2 * np.pi * vals / period)
    return df


def make_controlled_drift(n: int = 12000, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    date = pd.date_range("2016-01-01", periods=n, freq="h")
    daily = np.sin(2 * np.pi * t / 24)
    weekly = np.cos(2 * np.pi * t / (24 * 7))
    slow = np.sin(2 * np.pi * t / (24 * 60))
    signal = daily + 0.6 * weekly + 0.25 * rng.normal(size=n)
    split_a = int(n * 0.80)
    regime = np.ones(n)
    for st in range(split_a, n, 24 * 21):
        regime[st : st + 24 * 21] = (
            1 if ((st - split_a) // (24 * 21)) % 2 == 0 else -1
        )
    hu = signal + 0.15 * rng.normal(size=n)
    mu = 0.7 * signal + 0.4 * slow + 0.15 * rng.normal(size=n)
    lu = -0.5 * signal + 0.3 * weekly + 0.15 * rng.normal(size=n)
    base = 12 + 1.3 * slow + 0.2 * weekly
    ot = (
        base
        + 0.35 * np.roll(base, 24)
        + 1.9 * regime * np.roll(signal, 24)
        + 0.22 * rng.normal(size=n)
    )
    ot[:24] = (
        base[:24] + 1.9 * signal[:24] + 0.22 * rng.normal(size=24)
    )
    return pd.DataFrame(
        {
            "date": date,
            "HUFL": hu,
            "HULL": hu * 0.45 + 0.1 * rng.normal(size=n),
            "MUFL": mu,
            "MULL": mu * 0.45 + 0.1 * rng.normal(size=n),
            "LUFL": lu,
            "LULL": lu * 0.45 + 0.1 * rng.normal(size=n),
            "OT": ot.astype("float32"),
        }
    )


def load_dataset(name: str) -> dict:
    if name == "ControlledDrift":
        df = make_controlled_drift()
    elif name == "ETTSwitch":
        h1 = pd.read_csv(ROOT / "ETTh1.csv")
        h2 = pd.read_csv(ROOT / "ETTh2.csv")
        total = min(16000, len(h1), len(h2))
        prefix = int(total * 0.80)
        block = 24 * 7
        parts = [h1.iloc[:prefix].copy()]
        pos1 = prefix
        pos2 = prefix
        while sum(len(p) for p in parts) < total:
            cur_len = sum(len(p) for p in parts)
            if ((cur_len - prefix) // block) % 2 == 0:
                seg = h2.iloc[pos2 : pos2 + block].copy()
                pos2 += block
            else:
                seg = h1.iloc[pos1 : pos1 + block].copy()
                pos1 += block
            if len(seg) == 0:
                break
            parts.append(seg)
        df = pd.concat(parts, ignore_index=True).iloc[:total].copy()
        df["date"] = pd.date_range("2016-01-01", periods=len(df), freq="h")
    else:
        raise ValueError(name)

    df = add_time_features(df)
    time_cols = ["hour_sin", "hour_cos", "dow_sin", "dow_cos", "doy_sin", "doy_cos"]
    cols = BASE_COLS + time_cols
    raw_x = df[cols].values.astype("float32")
    raw_y = df["OT"].values.astype("float32")
    xs, ys, y_last, dates = [], [], [], []
    for i in range(len(df) - LOOKBACK - HORIZON + 1):
        xs.append(raw_x[i : i + LOOKBACK])
        ys.append(raw_y[i + LOOKBACK + HORIZON - 1])
        y_last.append(raw_y[i + LOOKBACK - 1])
        dates.append(df["date"].iloc[i + LOOKBACK + HORIZON - 1])
    return {
        "name": name,
        "raw_ot": raw_y,
        "X": np.stack(xs),
        "y": np.asarray(ys, dtype="float32"),
        "y_last": np.asarray(y_last, dtype="float32"),
        "dates": pd.to_datetime(pd.Series(dates)),
    }


def softmax(a: np.ndarray, axis: int = -1) -> np.ndarray:
    a = a - np.max(a, axis=axis, keepdims=True)
    ea = np.exp(a)
    return ea / np.sum(ea, axis=axis, keepdims=True)


def rpa_features(
    xseq: np.ndarray, d_model: int = D_MODEL, seed: int = 42, chunk: int = 4096
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    nf = xseq.shape[-1]
    w_in = rng.normal(0, 1 / math.sqrt(nf), size=(nf, d_model)).astype("float32")
    w_q = rng.normal(0, 1 / math.sqrt(d_model), size=(d_model, d_model)).astype("float32")
    w_k = rng.normal(0, 1 / math.sqrt(d_model), size=(d_model, d_model)).astype("float32")
    w_v = rng.normal(0, 1 / math.sqrt(d_model), size=(d_model, d_model)).astype("float32")
    pos = np.arange(xseq.shape[1])[:, None].astype("float32")
    div = np.exp(
        np.arange(0, d_model, 2).astype("float32")
        * (-math.log(10000.0) / d_model)
    )
    pe = np.zeros((xseq.shape[1], d_model), dtype="float32")
    pe[:, 0::2] = np.sin(pos * div)
    pe[:, 1::2] = np.cos(pos * div)
    out = []
    for st in range(0, len(xseq), chunk):
        z = xseq[st : st + chunk] @ w_in + pe[None, :, :]
        q = z[:, -1, :] @ w_q
        k = z @ w_k
        v = z @ w_v
        scores = np.einsum("bd,bld->bl", q, k) / math.sqrt(d_model)
        alpha = softmax(scores, axis=1)
        h = np.einsum("bl,bld->bd", alpha, v)
        out.append(
            np.concatenate([h, v.mean(axis=1), v.std(axis=1)], axis=1).astype(
                "float32"
            )
        )
    return np.vstack(out)


def sgd_update(
    w: np.ndarray,
    b: float,
    xb: np.ndarray,
    yb: np.ndarray,
    eta: float = LOCAL_LR,
    l2: float = L2,
) -> tuple[np.ndarray, float]:
    xb = np.asarray(xb, dtype="float32")
    yb = np.asarray(yb, dtype="float32")
    err = xb @ w + b - yb
    w = w - eta * (((xb.T @ err) / len(yb) + l2 * w).astype("float32"))
    b = float(b - eta * float(np.mean(err)))
    return w.astype("float32"), b


def balanced_indices(size: int, count: int) -> np.ndarray:
    count = min(size, count)
    if count <= 0:
        return np.empty(0, dtype=int)
    return np.unique(np.linspace(0, size - 1, count).round().astype(int))


def prepare_split(data: dict) -> dict:
    x = data["X"]
    y = data["y"]
    y_last = data["y_last"]
    n = len(x)
    n_train = int(n * 0.60)
    n_val = int(n * 0.20)
    train_idx = np.arange(n_train)
    val_idx = np.arange(n_train, n_train + n_val)
    test_idx = np.arange(n_train + n_val, n)
    train_fit_idx = train_idx[::2]

    feat_scaler = StandardScaler().fit(x[train_idx].reshape(-1, x.shape[-1]))
    y_scaler = StandardScaler().fit(y[train_idx].reshape(-1, 1))
    xs = feat_scaler.transform(x.reshape(-1, x.shape[-1])).reshape(x.shape).astype(
        "float32"
    )
    ys = y_scaler.transform(y.reshape(-1, 1)).ravel().astype("float32")
    yls = y_scaler.transform(y_last.reshape(-1, 1)).ravel().astype("float32")
    resid = (ys - yls).astype("float32")

    raw = data["raw_ot"]
    mase_den = float(
        np.maximum(
            np.mean(
                np.abs(
                    raw[HORIZON : n_train + LOOKBACK + HORIZON]
                    - raw[: n_train + LOOKBACK]
                )
            ),
            1e-6,
        )
    )

    def inv(z: np.ndarray) -> np.ndarray:
        return y_scaler.inverse_transform(np.asarray(z).reshape(-1, 1)).ravel()

    return {
        "target": y,
        "mase_den": mase_den,
        "xs": xs,
        "ys": ys,
        "yls": yls,
        "resid": resid,
        "n_train": n_train,
        "n_val": n_val,
        "train_idx": train_idx,
        "val_idx": val_idx,
        "test_idx": test_idx,
        "train_fit_idx": train_fit_idx,
        "inv": inv,
    }


def choose_gate(split: dict) -> float:
    val_idx = split["val_idx"]
    y = split["target"]
    yls = split["yls"]
    resid = split["resid"]
    inv = split["inv"]
    model = Ridge(alpha=1.0, solver="cholesky").fit(
        split["embedding"][split["train_fit_idx"]], resid[split["train_fit_idx"]]
    )
    split["static_model"] = model
    val_resid = model.predict(split["embedding"][val_idx])
    scores = [
        mean_squared_error(
            y[val_idx],
            inv(yls[val_idx] + gate * val_resid),
        )
        for gate in GATE_GRID
    ]
    return float(GATE_GRID[int(np.argmin(scores))])


def simulate(
    split: dict,
    mode: str,
    target_budget: int | None = None,
) -> tuple[dict, dict]:
    allowed = {"local", "periodic", "drift", "combined"}
    if mode not in allowed:
        raise ValueError(mode)

    test_idx = split["test_idx"]
    feat = split["embedding"]
    resid = split["resid"]
    yls = split["yls"]
    ys = split["ys"]
    inv = split["inv"]
    val_idx = split["val_idx"]
    model = split["static_model"]
    gate = split["gate"]
    w = model.coef_.astype("float32").copy()
    b = float(model.intercept_)

    val_resid = model.predict(feat[val_idx])
    val_err = np.abs(val_resid - resid[val_idx])
    ph_mean = float(val_err.mean())
    ph_lambda = float(ph_mean + 5 * val_err.std() + 1e-6)
    smoothed_error = ph_mean
    cumulative = 0.0
    minimum_cumulative = 0.0

    queue: list[tuple[np.ndarray, float]] = []
    replay_x: list[np.ndarray] = []
    replay_y: list[float] = []
    predictions: list[float] = []
    drift_steps: list[int] = []
    periodic_steps: list[int] = []
    total_gradient_samples = 0
    cloud_gradient_samples = 0
    local_gradient_samples = 0
    budget_equalizer_samples = 0
    parameter_updates = 0
    last_drift_step = -10**9
    n_test = len(test_idx)

    def remaining() -> int | None:
        if target_budget is None:
            return None
        return max(0, target_budget - total_gradient_samples)

    def use_update(xb: np.ndarray, yb: np.ndarray, source: str) -> bool:
        nonlocal w, b, total_gradient_samples
        nonlocal cloud_gradient_samples, local_gradient_samples, parameter_updates
        rem = remaining()
        if rem is not None:
            if rem <= 0:
                return False
            if len(yb) > rem:
                keep = balanced_indices(len(yb), rem)
                xb = xb[keep]
                yb = yb[keep]
        w, b = sgd_update(w, b, xb, yb)
        used = len(yb)
        total_gradient_samples += used
        parameter_updates += 1
        if source == "cloud":
            cloud_gradient_samples += used
        else:
            local_gradient_samples += used
        return True

    for step, idx in enumerate(test_idx):
        predictions.append(yls[idx] + gate * float(feat[idx] @ w + b))
        queue.append((feat[idx], float(resid[idx])))

        if len(queue) > HORIZON:
            xb, yb = queue.pop(0)
            replay_x.append(xb)
            replay_y.append(yb)
            if len(replay_x) > REPLAY_CAP:
                replay_x.pop(0)
                replay_y.pop(0)

            err = abs(float(xb @ w + b) - yb)
            smoothed_error = 0.995 * smoothed_error + 0.005 * err
            cumulative += err - smoothed_error - 0.01
            minimum_cumulative = min(minimum_cumulative, cumulative)

            drift_ready = (
                mode in {"drift", "combined"}
                and cumulative - minimum_cumulative > ph_lambda
                and len(replay_x) > DRIFT_REPLAY_MIN
                and (step - last_drift_step) >= COOLDOWN_HOURS
            )
            periodic_ready = (
                mode in {"periodic", "combined"}
                and step > 0
                and step % PERIODIC_INTERVAL == 0
                and len(replay_x) > PERIODIC_REPLAY_MIN
            )

            if drift_ready or periodic_ready:
                if drift_ready:
                    use_n = len(replay_x)
                    drift_steps.append(step)
                    last_drift_step = step
                    cumulative = 0.0
                    minimum_cumulative = 0.0
                else:
                    use_n = min(128, len(replay_x))
                    periodic_steps.append(step)
                use_x = np.asarray(replay_x[-use_n:], dtype="float32")
                use_y = np.asarray(replay_y[-use_n:], dtype="float32")
                for _ in range(2):
                    if not use_update(use_x, use_y, "cloud"):
                        break
            else:
                use_update(xb.reshape(1, -1), np.asarray([yb]), "local")

            if (
                target_budget is not None
                and step % BUDGET_CHECKPOINT == BUDGET_CHECKPOINT - 1
                and len(replay_x) >= 32
            ):
                expected = int(math.floor(target_budget * (step + 1) / n_test))
                to_add = expected - total_gradient_samples
                if to_add > 0:
                    use_n = min(to_add, len(replay_x))
                    positions = balanced_indices(len(replay_x), use_n)
                    extra_x = np.asarray(replay_x, dtype="float32")[positions]
                    extra_y = np.asarray(replay_y, dtype="float32")[positions]
                    before = total_gradient_samples
                    use_update(extra_x, extra_y, "local")
                    budget_equalizer_samples += total_gradient_samples - before

    if target_budget is not None and total_gradient_samples < target_budget and replay_x:
        to_add = min(target_budget - total_gradient_samples, len(replay_x))
        positions = balanced_indices(len(replay_x), to_add)
        extra_x = np.asarray(replay_x, dtype="float32")[positions]
        extra_y = np.asarray(replay_y, dtype="float32")[positions]
        before = total_gradient_samples
        use_update(extra_x, extra_y, "local")
        budget_equalizer_samples += total_gradient_samples - before

    prediction = inv(np.asarray(predictions, dtype="float32"))
    y_true = split["target"][test_idx]
    metrics = {
        "RMSE": math.sqrt(mean_squared_error(y_true, prediction)),
        "MAE": mean_absolute_error(y_true, prediction),
        "MASE": mean_absolute_error(y_true, prediction) / split["mase_den"],
    }
    audit = {
        "gate": gate,
        "ph_threshold": ph_lambda,
        "drift_events": len(drift_steps),
        "periodic_events": len(periodic_steps),
        "gradient_samples": total_gradient_samples,
        "local_gradient_samples": local_gradient_samples,
        "cloud_gradient_samples": cloud_gradient_samples,
        "budget_equalizer_samples": budget_equalizer_samples,
        "parameter_updates": parameter_updates,
    }
    return metrics, audit


def run() -> None:
    metric_rows: list[dict] = []
    audit_rows: list[dict] = []
    summaries: dict[str, object] = {}

    for dataset_name in ["ETTSwitch", "ControlledDrift"]:
        print(f"Running reviewer-2 controls: {dataset_name}", flush=True)
        data = load_dataset(dataset_name)
        base_split = prepare_split(data)
        for seed in SEEDS:
            split = dict(base_split)
            split["embedding"] = rpa_features(split["xs"], seed=seed)
            split["gate"] = choose_gate(split)

            combined_metrics, combined_audit = simulate(split, "combined")
            target = int(combined_audit["gradient_samples"])
            variants = {"AE-RPA combined": (combined_metrics, combined_audit)}
            for label, mode in [
                ("Local-update-only", "local"),
                ("Periodic-refresh-only", "periodic"),
                ("Drift-refresh-only", "drift"),
            ]:
                variants[label] = simulate(split, mode, target_budget=target)

            for label, (metrics, audit) in variants.items():
                metric_rows.append(
                    {
                        "dataset": dataset_name,
                        "seed": seed,
                        "model": label,
                        **metrics,
                    }
                )
                audit_rows.append(
                    {
                        "dataset": dataset_name,
                        "seed": seed,
                        "model": label,
                        **audit,
                    }
                )
            print(f"  seed {seed}: budget={target}", flush=True)

    metrics_df = pd.DataFrame(metric_rows)
    audit_df = pd.DataFrame(audit_rows)
    summary_df = (
        metrics_df.groupby(["dataset", "model"], as_index=False)
        .agg(
            RMSE_mean=("RMSE", "mean"),
            RMSE_std=("RMSE", lambda x: x.std(ddof=1)),
            MAE_mean=("MAE", "mean"),
            MAE_std=("MAE", lambda x: x.std(ddof=1)),
            MASE_mean=("MASE", "mean"),
            MASE_std=("MASE", lambda x: x.std(ddof=1)),
        )
        .sort_values(["dataset", "RMSE_mean"])
    )
    budget_summary = (
        audit_df.groupby(["dataset", "model"], as_index=False)
        .agg(
            gradient_samples_mean=("gradient_samples", "mean"),
            gradient_samples_std=("gradient_samples", "std"),
            local_gradient_samples_mean=("local_gradient_samples", "mean"),
            cloud_gradient_samples_mean=("cloud_gradient_samples", "mean"),
            budget_equalizer_samples_mean=("budget_equalizer_samples", "mean"),
            drift_events_mean=("drift_events", "mean"),
            periodic_events_mean=("periodic_events", "mean"),
            parameter_updates_mean=("parameter_updates", "mean"),
        )
        .sort_values(["dataset", "model"])
    )

    paired_rows: list[dict] = []
    for dataset_name, group in metrics_df.groupby("dataset"):
        pivot = group.pivot(index="seed", columns="model", values="RMSE")
        combined = pivot["AE-RPA combined"]
        for comparator in (
            "Local-update-only",
            "Periodic-refresh-only",
            "Drift-refresh-only",
        ):
            difference = combined - pivot[comparator]
            statistic, pvalue = ttest_rel(combined, pivot[comparator])
            paired_rows.append(
                {
                    "dataset": dataset_name,
                    "comparison": f"AE-RPA combined minus {comparator}",
                    "n_pairs": int(difference.size),
                    "mean_rmse_difference": float(difference.mean()),
                    "paired_t_statistic": float(statistic),
                    "paired_p_value_two_sided": float(pvalue),
                }
            )
    paired_df = pd.DataFrame(paired_rows)

    metrics_df.to_csv(RESDIR / "reviewer2_controls_by_dataset_seed.csv", index=False)
    audit_df.to_csv(RESDIR / "reviewer2_control_budget_audit.csv", index=False)
    summary_df.to_csv(RESDIR / "reviewer2_control_summary.csv", index=False)
    budget_summary.to_csv(RESDIR / "reviewer2_control_budget_summary.csv", index=False)
    paired_df.to_csv(RESDIR / "reviewer2_paired_tests.csv", index=False)
    for dataset_name, group in summary_df.groupby("dataset"):
        summaries[dataset_name] = group.to_dict(orient="records")
    with open(RESDIR / "reviewer2_control_summary.json", "w", encoding="utf-8") as f:
        json.dump(summaries, f, indent=2)

    print(summary_df.round(4).to_string(index=False))
    print(budget_summary.round(4).to_string(index=False))
    print(paired_df.round(6).to_string(index=False))


if __name__ == "__main__":
    run()
