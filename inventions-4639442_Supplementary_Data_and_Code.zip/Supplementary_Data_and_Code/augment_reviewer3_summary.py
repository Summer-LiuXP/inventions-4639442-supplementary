"""Add confidence intervals and paired boundary comparisons to Reviewer-3 results.

Run this script after ``run_reviewer3_analyses.py``. It reads the seed-level
outputs, adds 95% paired t confidence intervals, and writes supplementary
statistical tables. No experiment is rerun.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from scipy.stats import ttest_rel, wilcoxon


ROOT = Path(__file__).resolve().parent
RESDIR = ROOT / "results"
KEYS = ["dataset", "experiment", "model", "setting"]


def ci_mean(values: np.ndarray) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    if values.size < 2:
        return float(values.mean()), float("nan")
    half_width = student_t.ppf(0.975, values.size - 1) * values.std(ddof=1) / math.sqrt(values.size)
    return float(values.mean() - half_width), float(values.mean() + half_width)


def paired_summary(left: np.ndarray, right: np.ndarray) -> dict:
    left = np.asarray(left, dtype=float)
    right = np.asarray(right, dtype=float)
    difference = left - right
    ci_low, ci_high = ci_mean(difference)
    t_result = ttest_rel(left, right)
    try:
        wilcoxon_result = wilcoxon(difference, alternative="two-sided")
        wilcoxon_statistic = float(wilcoxon_result.statistic)
        wilcoxon_p = float(wilcoxon_result.pvalue)
    except ValueError:
        wilcoxon_statistic = float("nan")
        wilcoxon_p = float("nan")
    standard_deviation = difference.std(ddof=1)
    return {
        "n_pairs": int(difference.size),
        "mean_difference": float(difference.mean()),
        "ci95_low": ci_low,
        "ci95_high": ci_high,
        "paired_t_statistic": float(t_result.statistic),
        "paired_t_p_value": float(t_result.pvalue),
        "cohens_dz": float(difference.mean() / standard_deviation)
        if standard_deviation > 0
        else float("nan"),
        "wilcoxon_statistic": wilcoxon_statistic,
        "wilcoxon_p_value": wilcoxon_p,
    }


def write_boundary_comparisons() -> None:
    boundary = pd.read_csv(RESDIR / "reviewer3_boundary_metrics_by_seed.csv")
    rows = []
    for (dataset, window), group in boundary.groupby(["dataset", "window_hours"]):
        for metric, value_column in [
            ("post-window RMSE", "post_rmse"),
            ("post-minus-pre change", "post_minus_pre"),
        ]:
            pivot = group.pivot(index="seed", columns="model", values=value_column)
            row = {
                "dataset": dataset,
                "window_hours": int(window),
                "metric": metric,
                "comparison": "AE-RPA combined minus Static RPA (gated)",
            }
            row.update(
                paired_summary(
                    pivot["AE-RPA combined"].values,
                    pivot["Static RPA (gated)"].values,
                )
            )
            rows.append(row)
    pd.DataFrame(rows).to_csv(RESDIR / "reviewer3_boundary_comparisons.csv", index=False)


def write_sensitivity_summary_with_intervals() -> None:
    by_seed = pd.read_csv(RESDIR / "reviewer3_sensitivity_by_seed.csv")
    summary = pd.read_csv(RESDIR / "reviewer3_sensitivity_summary.csv")
    intervals = by_seed.groupby(KEYS, as_index=False).agg(
        RMSE_ci95_low=("RMSE", lambda values: ci_mean(values)[0]),
        RMSE_ci95_high=("RMSE", lambda values: ci_mean(values)[1]),
        drift_events_ci95_low=("drift_events", lambda values: ci_mean(values)[0]),
        drift_events_ci95_high=("drift_events", lambda values: ci_mean(values)[1]),
    )
    summary = summary.drop(
        columns=[
            "RMSE_ci95_low",
            "RMSE_ci95_high",
            "drift_events_ci95_low",
            "drift_events_ci95_high",
        ],
        errors="ignore",
    )
    summary.merge(intervals, on=KEYS, how="left").to_csv(
        RESDIR / "reviewer3_sensitivity_summary.csv", index=False
    )


def main() -> None:
    required = [
        RESDIR / "reviewer3_boundary_metrics_by_seed.csv",
        RESDIR / "reviewer3_sensitivity_by_seed.csv",
        RESDIR / "reviewer3_sensitivity_summary.csv",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Run run_reviewer3_analyses.py first. Missing: " + ", ".join(missing))
    write_boundary_comparisons()
    write_sensitivity_summary_with_intervals()
    print("Added boundary comparisons and sensitivity confidence intervals.")


if __name__ == "__main__":
    main()
